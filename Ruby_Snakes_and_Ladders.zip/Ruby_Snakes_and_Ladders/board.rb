class Board

  attr_reader :tiles

  def initialize(tiles)
    @tiles = tiles
  end


end
