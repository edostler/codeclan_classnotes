
class Tile

  attr_reader :position

  def initialize(position)
    @position = position
  end


end
